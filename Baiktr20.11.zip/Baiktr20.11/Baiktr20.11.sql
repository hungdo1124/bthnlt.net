﻿CREATE DATABASE QuanLyBanHang;
USE QuanLyBanHang;


CREATE TABLE SanPham (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tenSP VARCHAR(255) NOT NULL,
    gia DECIMAL(10, 2) NOT NULL,
    hangSX VARCHAR(255) NOT NULL
);


CREATE TABLE KhachHang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tenKH VARCHAR(255) NOT NULL,
    diachi VARCHAR(255),
    sdt VARCHAR(15)
);


CREATE TABLE DonHang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    khachhangid INT,
    sanphamid INT,
    soluong INT NOT NULL,
    ngaymua DATE NOT NULL,
    FOREIGN KEY (khachhangid) REFERENCES KhachHang(id) ON DELETE CASCADE,
    FOREIGN KEY (sanphamid) REFERENCES SanPham(id) ON DELETE CASCADE
);


CREATE TABLE NguoiDung (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tendangnhap VARCHAR(255) UNIQUE NOT NULL,
    matkhau VARCHAR(255) NOT NULL
);


INSERT INTO SanPham (tenSP, gia, hangSX)
VALUES
('Điện thoại Samsung Galaxy S23', 25000000, 'Samsung'),
('Laptop Dell XPS 13', 32000000, 'Dell'),
('Tai nghe Sony WH-1000XM5', 9000000, 'Sony'),
('Smartwatch Apple Watch Series 8', 12000000, 'Apple');


INSERT INTO KhachHang (tenKH, diachi, sdt)
VALUES
('Nguyễn Văn A', 'Hà Nội', '0123456789'),
('Trần Thị B', 'Hồ Chí Minh', '0987654321'),
('Lê Văn C', 'Đà Nẵng', '0912345678');


INSERT INTO DonHang (khachhangid, sanphamid, soluong, ngaymua)
VALUES
(1, 1, 1, '2024-11-01'),
(2, 2, 1, '2024-11-05'),
(1, 3, 2, '2024-11-10'),
(3, 4, 1, '2024-11-15');


INSERT INTO NguoiDung (tendangnhap, matkhau)
VALUES
('admin', '123456'),
('user1', 'password1'),
('user2', 'password2');
